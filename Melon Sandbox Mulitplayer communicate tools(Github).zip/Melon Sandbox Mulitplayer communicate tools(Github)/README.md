如何下载联机交流工具？
iOS:
长按文件，点打开方式，点Melon Sandbox，之后进游戏点Add或者Add and exit(这个不推荐)
安卓:
使用MT管理器，把Melmod文件放游戏文件里
如何使用联机交流工具？
在联机中放出即可，位于living栏的text项
注：不要编辑，不然它会无法放置，直接坏掉；该版本只支持38.0~38.5，过去(虽然过去没联机)与未来的版本不支持请联系作者(veo-melon@outlook.com或者Bilibili Veo-melon)做补丁